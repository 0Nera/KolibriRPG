#include <math.h>

double   pow(double x, double y)
{
	return exp(y * log(x));
}
