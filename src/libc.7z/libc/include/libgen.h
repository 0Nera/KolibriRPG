#ifndef __KTCC_LIBGEN_H__
#define __KTCC_LIBGEN_H__

char *basename(char *path);
char *dirname(char *path);

#endif // __KTCC_LIBGEN_H__
