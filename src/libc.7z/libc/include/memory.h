#ifndef _MEMORY_H
#define _MEMORY_H

#ifndef _STRING_H
    #include <string.h>
#endif
#endif
 
