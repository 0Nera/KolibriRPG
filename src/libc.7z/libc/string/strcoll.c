#include <string.h>

int strcoll(const char* string1,const char* string2)
{
	return strcmp(string1,string2);
}
