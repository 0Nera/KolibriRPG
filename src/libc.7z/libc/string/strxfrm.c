int strxfrm(char* strDest, const char* strSource, int count)
{
	return 0;
}