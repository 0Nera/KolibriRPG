#include<conio.h>

int getchar ( void )
{
	return con_getch();
}
